-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2022 at 11:27 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--
CREATE DATABASE IF NOT EXISTS `login` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `login`;

-- --------------------------------------------------------

--
-- Table structure for table `table 1`
--

CREATE TABLE `table 1` (
  `S.No.` int(11) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(11) NOT NULL,
  `Date` int(11) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `table 1`
--

INSERT INTO `table 1` (`S.No.`, `Email`, `Password`, `Date`) VALUES
(12, 'Dineshkushwah@gmail.com', '27081996', 2147483647),
(14, 'Dineshkushwah@gmail.com', '254683', 2147483647),
(15, 'docu.myfamily@gmail.com', 'ioufamily', 2147483647),
(16, 'pawan@gmail.com', 'hello i am ', 2147483647),
(19, 'Pawankushwah2005@gmail.com', '25March2005', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `table 2`
--

CREATE TABLE `table 2` (
  `S.No.` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `email` text NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `table 2`
--

INSERT INTO `table 2` (`S.No.`, `firstname`, `lastname`, `email`, `username`, `password`, `date`) VALUES
(1, 'pawan', 'kushwah', 'pawankuswah2005@gmail.com', 'pk05_weblogin', '25mar2005@', '2022-01-26 16:33:12'),
(7, 'shikhar', 'jain', 'shikharjain2424@gmail.com', 'shikhar_2004', 'shikhar_2004', '2022-01-27 17:54:16'),
(8, 'muskan', 'kushwah', 'muskkush2004@gmail.com', 'pk05_insta', '25122004', '2022-01-27 18:12:57'),
(29, 'pawan', 'kushwah', 'Pawankushwah2005@gmail.com', 'pk05_admin', 'admin', '2022-01-28 15:03:29'),
(30, 'pawan', 'kushwah', 'Pawangame.com@gmail.com', 'pk05_test', 'admin', '2022-01-28 15:18:09'),
(32, 'ashok', 'kushwah', 'Pawangame.com@gmail.com', 'pk05_ashok', 'admin', '2022-01-28 16:03:14');

-- --------------------------------------------------------

--
-- Table structure for table `table 3`
--

CREATE TABLE `table 3` (
  `S.No.` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(225) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `table 3`
--

INSERT INTO `table 3` (`S.No.`, `firstname`, `lastname`, `email`, `username`, `password`, `date`) VALUES
(1, 'Pk', 'kushwah', 'Pawangame.com@gmail.com', 'pk05_test2', '$2y$10$7tQy8q8ofm6Cn2hS3BHNm.JlDEyRFYhNH6v1sWP7pAYP5wcZpvkBe', '2022-02-01 15:49:22'),
(2, 'ashok', 'kushwah', 'ashokkushwah1972@gmail.com', 'ashok', '$2y$10$BSk4QydxQvcjRKm63MoZ1etIrK9wwkmV0Kf9DvpYaOvxr3xZm4cwi', '2022-02-01 16:27:49'),
(3, 'pawan', 'kushwah', 'Pawangame.com@gmail.com', 'pawan', '$2y$10$GXBIEPMiTPsgpi4IbMAxBer1pdFDlaYw1AykKTAtswqEu1WAgXfCK', '2022-02-02 22:03:01'),
(17, 'HEMANT', 'KUSHWAH', 'HEMANTKUSH90@GMAIL.COM', 'HEMKUSH', '$2y$10$6Tmp/PLHjQXM9ZuX6xHlE.eTEQFsNaxu1Sqh3lfO2F4dHLPeYDimm', '2022-02-03 17:51:31'),
(18, 'pawan', 'kushwah', 'Pawankushwah2005@gmail.com', 'pawan_2005', '$2y$10$AWodwsgBRtNLho.CBhUOueD3KYtfAQMXSbyYq0AWq8k8kMvgtEf.C', '2022-02-12 14:17:24'),
(19, 'pawan', 'kushwah', 'Pawangame.com@gmail.com', 'pawankushw', '$2y$10$5G.XbotA68OK9/mnPlced.BzTxWWIIdZs8lrYybIdQ9ASmiJyqo5O', '2022-03-24 23:34:27'),
(20, '', '', '', '', '$2y$10$uzyW2fNh6ROPdeX0/oEp2ez43KWpj.9SY3.O8d0exlKhY9Ek7444y', '2022-03-24 23:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `todolist_data`
--

CREATE TABLE `todolist_data` (
  `S.No.` int(11) NOT NULL,
  `note-title` varchar(30) NOT NULL,
  `note-description` varchar(200) NOT NULL,
  `Date` varchar(30) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `todolist_data`
--

INSERT INTO `todolist_data` (`S.No.`, `note-title`, `note-description`, `Date`) VALUES
(1, 'this is a test', 'this is a description from the test.', 'current_timestamp()'),
(2, 'this is test from webpage', '', '2022-02-04 13:04:23'),
(3, 'this is test from webpage', 'dfasdf', '2022-02-04 13:04:42'),
(4, 'this is test from webpage', 'dfasdf', '2022-02-04 13:07:50'),
(5, 'this is test from webpage', 'dfasdf', '2022-02-04 13:10:09'),
(6, 'this is test from webpage', 'dfasdf', '2022-02-04 13:11:27'),
(7, 'this is test from webpage', 'dfasdf', '2022-02-04 13:11:36'),
(8, 'this is test from webpage', 'dfasdf', '2022-02-04 13:12:02'),
(9, 'this is test from webpage', 'dfasdf', '2022-02-04 13:12:18'),
(10, 'now this is working', 'yesthis is working xorrectly\r\n', '2022-02-04 13:57:13'),
(11, 'now this is working', 'yesthis is working xorrectly\r\n', '2022-02-04 13:57:20'),
(12, '', '', '2022-02-04 13:57:35'),
(13, 'hello', 'hello', '2022-02-04 13:57:50'),
(14, 'pawna', 'pawna\r\n', '2022-02-04 13:58:38'),
(15, 'pawna', 'pawna\r\n', '2022-02-04 14:01:32'),
(16, 'pawna', 'pawna\r\n', '2022-02-04 14:04:12'),
(17, 'pawna', 'pawna\r\n', '2022-02-04 14:04:36'),
(18, '', '', '2022-02-05 11:41:00'),
(19, '', '', '2022-02-05 11:42:40'),
(20, 'now this is working', 'cvbcfghfsgh', '2022-02-12 14:13:37'),
(21, 'pawan', 'fgsdfgsd', '2022-02-12 14:13:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `table 1`
--
ALTER TABLE `table 1`
  ADD PRIMARY KEY (`S.No.`);

--
-- Indexes for table `table 2`
--
ALTER TABLE `table 2`
  ADD PRIMARY KEY (`S.No.`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `table 3`
--
ALTER TABLE `table 3`
  ADD PRIMARY KEY (`S.No.`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `todolist_data`
--
ALTER TABLE `todolist_data`
  ADD PRIMARY KEY (`S.No.`),
  ADD UNIQUE KEY `S.No.` (`S.No.`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `table 1`
--
ALTER TABLE `table 1`
  MODIFY `S.No.` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `table 2`
--
ALTER TABLE `table 2`
  MODIFY `S.No.` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `table 3`
--
ALTER TABLE `table 3`
  MODIFY `S.No.` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `todolist_data`
--
ALTER TABLE `todolist_data`
  MODIFY `S.No.` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
